<?php

use App\Exports\LeaderboardExport;
use App\Http\Controllers\AssignBonusController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CardAssignApiController;
use App\Http\Controllers\CardController;
use App\Http\Controllers\ChallengeActivityController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\GroupController;
use App\Http\Controllers\LeaderboardController;
use App\Http\Controllers\MatchController;
use App\Http\Controllers\OrganizationController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\PlayerController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\ScoreboardController;
use App\Http\Controllers\ScoreController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\SubGroupController;
use App\Http\Controllers\TeamController;
use App\Http\Controllers\TournamentController;
use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

// =============================================================================
// GUEST ROUTES (Public / Unauthenticated)
// =============================================================================
Route::middleware('guest')->group(function () {
    Route::get('/sign-in', [AuthController::class, 'registerLoginPage'])->name('login');
    Route::post('/login',  [AuthController::class, 'login'])->name('login.post');
    Route::post('/register', [AuthController::class, 'register'])->name('register.post');
});

// =============================================================================
// PUBLIC ROUTES (No login required)
// =============================================================================
Route::get('/',           [DashboardController::class,  'index'])->name('dashboard.index');
Route::get('/scoreboard', [ScoreboardController::class, 'index'])->name('scoreboard.index');
Route::get('/scoreboard/data', [ScoreboardController::class, 'getData'])->name('scoreboard.data');

Route::get('/bracket', [EventController::class, 'bracketBoard'])->name('bracket.index');
Route::get('/events/{event}/bracket', [EventController::class, 'bracket'])->name('events.bracket');

Route::get('/leaderboard/top-teams',   [LeaderboardController::class, 'fetchTopThreeTeams'])->name('leaderboard.fetchTopThreeTeams');
Route::get('/leaderboard/top-players', [LeaderboardController::class, 'fetchTopThreePlayers'])->name('leaderboard.fetchTopThreePlayers');

// Public leaderboard endpoints (read-only, used by dashboard widgets)
Route::get('/leaderboard-event',  [LeaderboardController::class, 'events'])->name('leaderboard.events');
Route::get('/leaderboard-datas',  [LeaderboardController::class, 'data'])->name('leaderboard.data');

// =============================================================================
// AUTHENTICATED ROUTES
// =============================================================================
Route::middleware('auth')->group(function () {

    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // =========================================================================
    // ADMIN ROUTES
    // =========================================================================
    Route::middleware('admin')->group(function () {
        Route::post('/assign-bonus', [AssignBonusController::class, 'store'])
        ->name('bonus.assign.store');
        // ---------------------------------------------------------------------
        // Score Management (Scoring page)
        // ---------------------------------------------------------------------
        Route::get('/scoring', [ScoreController::class, 'index'])->name('scoring.index');

        // Add Score modal — store
        Route::post('/scores',        [ScoreController::class, 'store'])->name('scores.store');
        Route::post('/scores/create', [ScoreController::class, 'store']);   // alias kept for backward compat

        // Inline & bulk edit — update by activity ID
        Route::post('/scores/update-by-id',   [ScoreController::class, 'updateById'])->name('scores.updateById');

        // Pre-fill existing score
        Route::get('/scores/existing', [ScoreController::class, 'getExistingScore'])->name('scores.existing');

        // Leaderboard event list & data (used by the Scoring page)
        Route::get('/leaderboard-events', [ScoreController::class, 'events'])->name('scores.events');
        Route::get('/leaderboard-data',   [ScoreController::class, 'data'])->name('scores.data');

        // Leaderboard export
        Route::get('/leaderboard-export', function (Request $request) {
            $eventId = $request->input('event_id');
            if (!$eventId || $eventId === '-- Select Event --') {
                return redirect()->back()->with('error', 'Please select a valid event.');
            }
            return Excel::download(new LeaderboardExport($eventId), 'leaderboard.xlsx');
        });

        // ---------------------------------------------------------------------
        // API — Ajax dropdown helpers
        // ---------------------------------------------------------------------
        Route::prefix('api')->name('api.')->group(function () {
            Route::get('/events/{event}/students',   [ScoreController::class, 'getEventStudents'])->name('events.students');
            Route::get('/events/{event}/teams',      [ScoreController::class, 'getEventTeams'])->name('events.teams');
            Route::get('/events/{event}/activities', [ScoreController::class, 'getEventActivities'])->name('events.activities');
            Route::get('/steam-categories',          [ScoreController::class, 'getSteamCategories'])->name('steam.categories');
            Route::get('/teams/{team}/students',     [ScoreController::class, 'getTeamStudents'])->name('teams.students');
        });

        // ---------------------------------------------------------------------
        // Hierarchy dropdowns (used by modals)
        // ---------------------------------------------------------------------
 // Event → Organizations
 Route::get('/events/{event}/organizations', [ScoreController::class, 'getEventOrganizations']);
        
 // Organization → Groups
 Route::get('/organizations/{id}/groups', [ScoreController::class, 'getOrganizationGroups']);
 
 // Group → SubGroups
 Route::get('/groups/{id}/subgroups', [ScoreController::class, 'getGroupSubgroups']);
 
 // Get filtered students (by group/subgroup)
 // Query params: ?group_id=X&sub_group_id=Y
 Route::get('/students', [ScoreController::class, 'getFilteredStudents']);
 
 // Get filtered teams (by group/subgroup)
 // Query params: ?group_id=X&sub_group_id=Y
 Route::get('/teams', [ScoreController::class, 'getFilteredTeams']);
 
 // Get students for a specific team
 Route::get('/team/{team}/students', [ScoreController::class, 'getTeamStudents']);

        // ---------------------------------------------------------------------
        // Users
        // ---------------------------------------------------------------------
        Route::get('/users',           [UserController::class, 'index'])->name('users.index');
        Route::get('/users/{id}/edit', [UserController::class, 'edit'])->name('users.edit');
        Route::put('/users/{id}',      [UserController::class, 'update'])->name('users.update');

        // ---------------------------------------------------------------------
        // Roles & Permissions
        // ---------------------------------------------------------------------
        Route::post('/roles',              [RoleController::class,      'store'])->name('roles.store');
        Route::put('/roles/{id}',          [RoleController::class,      'update'])->name('roles.update');
        Route::post('/permissions',        [PermissionController::class, 'store'])->name('permissions.store');
        Route::delete('/permissions/{id}', [PermissionController::class, 'destroy'])->name('permissions.destroy');
        Route::delete('/roles/{id}', [RoleController::class, 'destroy'])->name('roles.destroy');

        Route::prefix('api')->group(function() {
            Route::get('organizations/list', [CardAssignApiController::class, 'organizations'])->name('api.organizations.list');
            Route::get('groups/list', [CardAssignApiController::class, 'groups'])->name('api.groups.list');
            Route::get('teams/list', [CardAssignApiController::class, 'teams'])->name('api.teams.list');
            Route::get('teams/by-group/{group}', [CardAssignApiController::class, 'teamsByGroup']);
            Route::get('students/by-team/{team}', [CardAssignApiController::class, 'studentsByTeam']);
        });

        // ---------------------------------------------------------------------
        // Student / Player Management
        // ---------------------------------------------------------------------
        Route::get('/student',              [StudentController::class, 'index'])->name('student.index');
        Route::post('/student/store',       [StudentController::class, 'store'])->name('student.store');
        Route::post('/players/import',      [StudentController::class,  'import'])->name('student.import');
        Route::get('/players/{player}/edit',        [StudentController::class, 'edit'])->name('student.edit');
        Route::post('/players/{player}/update',     [StudentController::class, 'update'])->name('student.update');
        Route::delete('/player-destroy/{player}',          [StudentController::class, 'destroy'])->name('student.destroy');
        Route::post('/players/bulk-delete', [StudentController::class, 'bulkDelete'])->name('students.bulk.delete');
        // ---------------------------------------------------------------------
        // Team Management
        // ---------------------------------------------------------------------
        Route::post('/teams/store',             [TeamController::class, 'store'])->name('teams.store');
        Route::get('/teams-data',               [TeamController::class, 'teamsData'])->name('teams.data');
        Route::get('/view/{team}',              [TeamController::class, 'view'])->name('teams.view');
        Route::get('/teams/{team}',             [TeamController::class, 'edit'])->name('teams.edit');
        Route::post('/teams/update/{team}',     [TeamController::class, 'update'])->name('teams.update');
        Route::delete('/delete/{team}',         [TeamController::class, 'destroy'])->name('teams.destroy');
        Route::get('/teams-export',             [TeamController::class, 'export'])->name('teams.export');
        Route::post('/teams-import',            [TeamController::class, 'import'])->name('teams.import');
        Route::post('/teams/bulk-delete',       [TeamController::class, 'bulkDelete'])->name('teams.bulkDelete');
        Route::get('/teams/import/template',    [TeamController::class, 'importTemplate'])->name('teams.import.template');
        Route::get('/teams/list',               [TeamController::class, 'listTeam'])->name('teams.list');
        Route::get('/organizations/list',       [TeamController::class, 'list']);
        Route::get('/get-groups/{orgId}',       [TeamController::class, 'getGroups']);
        Route::get('/get-teams/{groupId}',      [TeamController::class, 'getTeams']);

        // ---------------------------------------------------------------------
        // Event Management
        // ---------------------------------------------------------------------
        Route::get('/events',                    [EventController::class, 'index'])->name('events.index');
        Route::post('/events/{event}/bracket/init',           [EventController::class, 'bracketInit'])->name('events.bracket.init');
        Route::post('/events/{event}/bracket/matches/{match}',[EventController::class, 'bracketUpdateMatch'])->name('events.bracket.match.update');
        Route::post('/events/store',             [EventController::class, 'store'])->name('events.store');
        Route::get('/events/{event}',            [EventController::class, 'show'])->name('events.show');
        Route::delete('/events/{event}',         [EventController::class, 'destroy'])->name('events.destroy');
        Route::post('/events/{event}/duplicate', [EventController::class, 'duplicate'])->name('events.duplicate');
        Route::get('/events/{event}/edit',       [EventController::class, 'edit'])->name('events.edit');
        Route::post('/events/{event}/update',    [EventController::class, 'update'])->name('events.update');
        Route::patch('/events/{event}/status',   [EventController::class, 'updateStatus'])->name('events.updateStatus');
        Route::get('/events/{event}/players',    [TeamController::class, 'playersByEvent'])->name('teams.get_players');
        Route::get('/events/{event}/teams', function (\App\Models\Event $event) {
            $teams = \App\Models\Team::where('event_id', $event->id)->get(['id', 'team_name']);
            return response()->json(['teams' => $teams]);
        })->name('events.teams');
        // Add these alongside your existing event routes
Route::get('/events/{event}/winner-teams', [EventController::class, 'getWinnerTeams']);
Route::post('/events/{event}/set-winner',  [EventController::class, 'setWinner']);
    // Results (summary) for a closed event
    Route::get('/events/{event}/results', [EventController::class, 'results']);

        // ---------------------------------------------------------------------
        // Tournament Management
        // ---------------------------------------------------------------------
        Route::get('/tournaments',                         [TournamentController::class, 'index'])->name('tournaments.index');
        Route::get('/tournaments/create',                  [TournamentController::class, 'create'])->name('tournaments.create');
        Route::post('/tournaments',                        [TournamentController::class, 'store'])->name('tournaments.store');
        Route::post('/tournament-match/{match}/winner',    [TournamentController::class, 'setWinner']);
        Route::post('/tournament-match/{match}/pin',       [TournamentController::class, 'generatePIN']);

        // ---------------------------------------------------------------------
        // Challenge Activity Management
        // ---------------------------------------------------------------------
        Route::post('/activities/store',                    [ChallengeActivityController::class, 'store'])->name('activities.store');
        Route::get('/activities/{activity}',                [ChallengeActivityController::class, 'show']);
        Route::post('/activities/{activity}/update',        [ChallengeActivityController::class, 'update']);
        Route::delete('/activities/{activity}/delete',      [ChallengeActivityController::class, 'destroy']);

        // ---------------------------------------------------------------------
        // Card Management
        // ---------------------------------------------------------------------
        Route::get('/cards',                  [CardController::class, 'index'])->name('cards.index');
        Route::post('/cards/store',           [CardController::class, 'store'])->name('cards.store');
        Route::get('/cards/{card}/edit',      [CardController::class, 'edit'])->name('cards.edit');
        Route::post('/cards/{card}/update',   [CardController::class, 'update'])->name('cards.update');
        Route::delete('/cards/{card}/delete', [CardController::class, 'destroy'])->name('cards.delete');
        Route::post('/card-assignments',      [CardController::class, 'assignCard'])->name('card.assignments.store');

        // ---------------------------------------------------------------------
        // Match Management
        // ---------------------------------------------------------------------
        Route::post('/matches',                    [MatchController::class, 'store'])->name('matches.store');
        Route::post('/matches/{id}/generate-pin',  [MatchController::class, 'generatePin'])->name('matches.generatePin');
        Route::post('/matches/{id}/round',         [MatchController::class, 'addRound'])->name('matches.addRound');
        Route::get('/matches/fetch',               [MatchController::class, 'fetch'])->name('matches.fetch');
        Route::delete('/matches/{id}',             [MatchController::class, 'destroy'])->name('matches.destroy');
        Route::get('/matches/teams',               [MatchController::class, 'fetchTeams'])->name('matches.teams');
        Route::post('/matches/{match}/round',      [MatchController::class, 'addRound'])->name('matches.round');
        Route::get('/matches/export/all',          [MatchController::class, 'exportAllSchedule'])->name('matches.export.all');

        // ---------------------------------------------------------------------
        // Organization & Group & SubGroup Management
        // ---------------------------------------------------------------------
        Route::get('/event/{eventId}/organizations',    [EventController::class,        'getOrganizations']);
        Route::get('/organization/{orgId}/groups',      [GroupController::class,        'getByOrganization']);
        Route::post('/organization/store',              [OrganizationController::class, 'store'])->name('organizations.store');
        Route::delete('/organizations/{organization}',  [OrganizationController::class, 'destroy'])->name('organizations.destroy');
        Route::post('/organizations/update/{id}',       [OrganizationController::class, 'update'])->name('organizations.update');

        Route::post('/groups',              [GroupController::class, 'store'])->name('groups.store');
        Route::post('/groups/update/{id}',  [GroupController::class, 'update'])->name('groups.update');
        Route::delete('/groups/{group}',    [GroupController::class, 'destroy'])->name('groups.destroy');
        Route::get('/groups/{group}/subgroups', [GroupController::class, 'subgroups']);

        Route::post('/subgroups/store',        [SubGroupController::class, 'store'])->name('subgroups.store');
        Route::delete('/subgroups/{subgroup}', [SubGroupController::class, 'destroy'])->name('subgroups.destroy');
        Route::get('/subgroup/fetch/{id}',     [SubGroupController::class, 'show'])->name('subgroup.fetch');
        Route::put('/subgroup/update/{subgroup}', [SubGroupController::class, 'update'])->name('subgroup.update');
        Route::get('/get-org-groups/{orgId}', [SubGroupController::class, 'getGroupByOrganization']);
        // ---------------------------------------------------------------------
        // Leaderboard (admin view)
        // ---------------------------------------------------------------------
        Route::get('/leaderboard', [LeaderboardController::class, 'index'])->name('leaderboard.index');
        Route::get('/event/{event}/students-leaderboard', [StudentController::class, 'leaderboard']);
        Route::post('/score/update-inline', [StudentController::class, 'updateScoreInline']);

        // ---------------------------------------------------------------------
        // Settings
        // ---------------------------------------------------------------------
        Route::get('/settings',                  [SettingController::class, 'index'])->name('settings.index');
        Route::post('/profile/update',           [SettingController::class, 'updateProfile'])->name('profile.update');
        Route::get('/settings/activities/fetch', [SettingController::class, 'fetchChallengeActivities'])->name('settings.activities.fetch');
        Route::delete('/users/{id}', [SettingController::class, 'destroyUser'])->name('setting.users.destroy');
    }); // end admin middleware

}); // end auth middleware