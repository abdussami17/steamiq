<?php

namespace App\Observers;

use App\Models\Activity;
use App\Models\Event;

class EventObserver
{
    /**
     * Handle the Event "created" event.
     */
    public function created(Event $event): void
    {
        Activity::create([
            'user_id' => auth()->id(),
            'description' => "New Event '{$event->name}' added",
            'type'    => 'event_created',
            'data' => json_encode(['event_id' => $event->id])
        ]);
    }

    /**
     * Handle the Event "updated" event.
     */
    public function updated(Event $event): void
    {
        Activity::create([
            'user_id' => auth()->id(),
            'description' => "Event '{$event->name}' updated",
            'type'    => 'event_updated',
            'data' => json_encode(['event_id' => $event->id])
        ]);
    }

    /**
     * Handle the Event "deleted" event.
     */
    public function deleted(Event $event): void
    {
        //
    }

    /**
     * Handle the Event "restored" event.
     */
    public function restored(Event $event): void
    {
        //
    }

    /**
     * Handle the Event "force deleted" event.
     */
    public function forceDeleted(Event $event): void
    {
        //
    }
}
